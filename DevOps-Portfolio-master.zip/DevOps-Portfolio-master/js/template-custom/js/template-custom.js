// Sticky menu
$('#header').sticky();

// Sticky menu
$('#header-2, #header-3').sticky();
// Preloader
$(window).on('load', function(e) {
	$('body').removeClass('loading');
});
